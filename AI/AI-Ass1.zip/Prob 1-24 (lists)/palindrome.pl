% 14: Check palindrome list using reverse_list

palindrome(L):- reverse_list(L, L).
