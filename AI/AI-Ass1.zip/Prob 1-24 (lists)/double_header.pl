% Prog 1: Determine if first two elements are same

double_header([X|[X|R]]).
