% Prog 9: our member check with append

our_member1(X, L):- append1(L1, [X|Rest], L).
