% Prog 5: 
same_length1(L1, L2):- my_length(L1, N), my_length(L2, N).
