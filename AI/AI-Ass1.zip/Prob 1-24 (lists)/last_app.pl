% 10: Determine last element of list using append

last1(L, X):- append1(L1, [X], L).
